# Bilibili Helper

## 1 install

```
npm install
```

## 2 build

**Build new Bilibili.js**

```
npm run build
```

**Generate new js from proto**

```
npm run build:proto
```
