import Client from './client'

export const $ = Client.getInstance('YouTube')
