# YouTube 去广告

## 1 install

```
npm install
```

## 2 build

**Build new YouTube.js**

```
npm run build
```

**Generate new youtube.ts from proto**

```
npm run build:proto
```
